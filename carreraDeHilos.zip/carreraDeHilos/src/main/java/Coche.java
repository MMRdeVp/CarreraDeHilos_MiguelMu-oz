
import java.awt.Color;
import java.awt.Label;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alumno
 */
public class Coche implements Runnable{
    
    private int recorrido = 0;
    private JLabel coche;
    
    public Coche(JLabel coche, int recorrido){
        this.coche = coche;
        this.recorrido=recorrido;
        
    }
    
 

    public int getRecorrido() {
        return recorrido;
    }

    

    public void setRecorrido(int recorrido) {
        this.recorrido = recorrido;
    }

   

    @Override
    public String toString() {
        return "Coche{" + "recorrido=" + recorrido;
    }
    
    
    

    @Override
    public void run() {
        
       
        
        while (this.coche.getX()<=550&&!CarreraDeHilos.fin) {
            
            int aux = (int) Math.random()*40+1;
            
            int r =(int) (Math.random()*7);
            
            int aceleracion = 0;
            
            if(r == 1){
            aceleracion = (int) (Math.random()*5);    
            }
            
            System.out.println(this.coche.getName() + "acel="+ aceleracion+ ","+ recorrido);
            
            setRecorrido(recorrido+aux+aceleracion);
            
            this.coche.setBounds(recorrido, this.coche.getY(), this.coche.getWidth(), this.coche.getHeight());
            
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Coche.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            if(this.coche.getX()>550){
               CarreraDeHilos.fin = true;
                
                
                CarreraDeHilos.mostrarInfo(this.coche.getName());
                
            }
             
        }
        
    }

   
    
}
